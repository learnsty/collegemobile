<?php

namespace Mailgun\Messages\Exceptions;

class MissingRequiredMIMEParameters extends \Exception
{
}
